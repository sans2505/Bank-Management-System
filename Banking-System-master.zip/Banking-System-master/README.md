Created a Banking system app 
